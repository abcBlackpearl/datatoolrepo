import React, { useState } from 'react';
import { FileUpload } from './components/FileUpload';
import { DifferenceTable } from './components/DifferenceTable';
import { compareCsvFiles, generateCsvFromDifferences, type CsvDifference } from './utils/csvUtils';
import { Download } from 'lucide-react';

function App() {
  const [easipolContent, setEasipolContent] = useState<string>('');
  const [groupsContent, setGroupsContent] = useState<string>('');
  const [differences, setDifferences] = useState<CsvDifference[]>([]);

  const handleCompare = () => {
    if (easipolContent && groupsContent) {
      const diffs = compareCsvFiles(easipolContent, groupsContent);
      setDifferences(diffs);
    }
  };

  const handleExport = () => {
    if (differences.length === 0) return;

    const csv = generateCsvFromDifferences(differences);
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'differences.csv';
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gray-100 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow px-6 py-8">
          <h1 className="text-2xl font-bold text-gray-900 mb-6">CSV Comparison Tool</h1>
          
          <div className="space-y-6">
            <FileUpload 
              label="Upload Easipol CSV" 
              onFileSelect={setEasipolContent} 
            />
            
            <FileUpload 
              label="Upload Groups CSV" 
              onFileSelect={setGroupsContent} 
            />

            <div className="flex gap-4">
              <button
                onClick={handleCompare}
                disabled={!easipolContent || !groupsContent}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Compare Files
              </button>

              {differences.length > 0 && (
                <button
                  onClick={handleExport}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Export Differences
                </button>
              )}
            </div>

            {differences.length > 0 && (
              <div className="mt-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">
                  Found {differences.length} differences
                </h2>
                <DifferenceTable differences={differences} />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;