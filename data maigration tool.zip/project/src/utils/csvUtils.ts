export interface CsvDifference {
  column: string;
  role: string;
  easipolValue: string;
  groupsValue: string;
}

export const parseCsvContent = (content: string): string[][] => {
  return content.split('\n').map(line => 
    line.split(',').map(cell => cell.trim())
  );
};

export const compareCsvFiles = (easipolContent: string, groupsContent: string): CsvDifference[] => {
  const easipolData = parseCsvContent(easipolContent);
  const groupsData = parseCsvContent(groupsContent);
  
  const differences: CsvDifference[] = [];
  const headers = easipolData[0];
  
  for (let i = 1; i < easipolData.length; i++) {
    const easipolRow = easipolData[i];
    const groupsRow = groupsData[i];
    
    if (!easipolRow || !groupsRow) continue;
    
    const role = easipolRow[0]; // Assuming first column is role
    
    headers.forEach((header, index) => {
      if (easipolRow[index] !== groupsRow[index]) {
        differences.push({
          column: header,
          role,
          easipolValue: easipolRow[index],
          groupsValue: groupsRow[index]
        });
      }
    });
  }
  
  return differences;
};

export const generateCsvFromDifferences = (differences: CsvDifference[]): string => {
  const headers = ['Column', 'Role', 'Easipol Value', 'Groups Value'];
  const rows = differences.map(diff => 
    `${diff.column},${diff.role},${diff.easipolValue},${diff.groupsValue}`
  );
  
  return [headers.join(','), ...rows].join('\n');
};