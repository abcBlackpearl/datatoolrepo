import React from 'react';
import type { CsvDifference } from '../utils/csvUtils';

interface DifferenceTableProps {
  differences: CsvDifference[];
}

export const DifferenceTable: React.FC<DifferenceTableProps> = ({ differences }) => {
  if (differences.length === 0) {
    return null;
  }

  return (
    <div className="mt-8 overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Column</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Role</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Easipol Value</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Groups Value</th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {differences.map((diff, index) => (
            <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{diff.column}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{diff.role}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{diff.easipolValue}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{diff.groupsValue}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};